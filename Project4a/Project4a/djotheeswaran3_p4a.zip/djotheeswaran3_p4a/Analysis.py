import Testing

Testing.testDummySet1()
Testing.testDummySet2()
Testing.testCar()
Testing.testConnect4()
